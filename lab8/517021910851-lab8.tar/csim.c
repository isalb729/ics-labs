/*
 * name: YuYaJie
 * loginId: ics517021910851
 */
#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
typedef struct
{
    unsigned long tag;
    int valid, lru;
}Line;
typedef struct 
{
    Line * lines;
}Set;
typedef struct 
{
    int s, E, b;
    Set *sets;
}Cache;
void init(int s, int E, int b, Cache *cache){
    cache->s = s;
    cache->E = E;
    cache->b = b;
    int S = 1 << s;
    cache->sets = (Set*) malloc(S * sizeof(Set));
    for (int i=0;i < S;i++){
        cache->sets[i].lines = (Line*) malloc(E * sizeof(Line));
        for (int j = 0; j < cache->E; j++) {
            cache->sets[i].lines[j].valid = 0;
            cache->sets[i].lines[j].lru = 0;
        }
    }
}
void visit(int v, int *hit_time, int *miss_time, int *evict_time, Cache *cache, int addr){
    addr >>=cache->b;
    int setNumber = (addr>>(cache->s)<<(cache->s))^addr;
    addr >>=cache->s;
    int tag = addr, full = 1;
    for (int j=0;j < cache->E;j++)  cache->sets[setNumber].lines[j].lru++;
    for (int i=0;i < cache->E; i++)
        if (cache->sets[setNumber].lines[i].valid){ 
            if (cache->sets[setNumber].lines[i].tag == tag){
            (*hit_time)++;
            if (v) printf(" hit");
            cache->sets[setNumber].lines[i].lru = 0;
            return;
            };
        }
        else full=0;
    if (full) {
        if (v) printf(" miss eviction");
        (*evict_time)++;
        (*miss_time)++;
        int lru_max_index = 0;
        for (int i=0;i < cache->E; i++)
            lru_max_index = (cache->sets[setNumber].lines[i].lru < cache->sets[setNumber].lines[lru_max_index].lru)?lru_max_index: i;
        cache->sets[setNumber].lines[lru_max_index].tag = tag;
        cache->sets[setNumber].lines[lru_max_index].lru = 0;
    }
        else {
            for (int i=0;i < cache->E; i++)
                if (!cache->sets[setNumber].lines[i].valid){
                    cache->sets[setNumber].lines[i].tag = tag;
                    cache->sets[setNumber].lines[i].lru = 0;
                    cache->sets[setNumber].lines[i].valid = 1;
                    if (v) printf(" miss");
                    (*miss_time)++;
                    return;
                }
        }
}
int main(int argc, char *argv[])
{
    int opt;
    int h=0, v=0, s=0, E=0, b=0;
    char *t;
    FILE *trace;
    while ((opt = getopt(argc, argv, "hvs:E:b:t:")) != -1) 
        switch (opt) {
            case 'h': 
                h = 1;
                break;
            case 's':
                s = atoi(optarg);
                break;
            case 'E':
                E = atoi(optarg);
                break;
            case 'v':
                v = 1;
                break;
            case 'b':
                b = atoi(optarg);
                break;
            case 't':
                t = optarg;
                break;
            case '?':
                fprintf(stderr, "%s: invalid option -- %c\nUsage: %s [-hv] -s <num> -E <num> -b <num> -t <file>\nOptions:\n  -h         Print this help message.\n  -v         Optional verbose flag.\n  -s <num>   Number of set index bits.\n  -E <num>   Number of lines per set.\n  -b <num>   Number of block offset bits.\n  -t <file>  Trace file.\n\nExamples:\n  linux>  ./csim-ref -s 4 -E 1 -b 4 -t traces/yi.trace\n  linux>  ./csim-ref -v -s 8 -E 2 -b 4 -t traces/yi.trace\n", argv[0], opt, argv[0]);
                exit(EXIT_FAILURE);
        }
    trace = fopen(t, "r");
    if (trace == NULL||!s||!E||!b) {
        fprintf(stderr, "%s: Missing required command line argument\nUsage: %s [-hv] -s <num> -E <num> -b <num> -t <file>\nOptions:\n  -h         Print this help message.\n  -v         Optional verbose flag.\n  -s <num>   Number of set index bits.\n  -E <num>   Number of lines per set.\n  -b <num>   Number of block offset bits.\n  -t <file>  Trace file.\n\nExamples:\n  linux>  ./csim-ref -s 4 -E 1 -b 4 -t traces/yi.trace\n  linux>  ./csim-ref -v -s 8 -E 2 -b 4 -t traces/yi.trace\n", argv[0], argv[0]);
        exit(EXIT_FAILURE);
    }
    if (h == 1){
        fprintf(stderr, "Usage: %s [-hv] -s <num> -E <num> -b <num> -t <file>\nOptions:\n  -h         Print this help message.\n  -v         Optional verbose flag.\n  -s <num>   Number of set index bits.\n  -E <num>   Number of lines per set.\n  -b <num>   Number of block offset bits.\n  -t <file>  Trace file.\n\nExamples:\n  linux>  ./csim-ref -s 4 -E 1 -b 4 -t traces/yi.trace\n  linux>  ./csim-ref -v -s 8 -E 2 -b 4 -t traces/yi.trace\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    Cache cache;
    init(s, E, b, &cache);
    char oper;
    unsigned long addr;
    int size, hit_time=0, miss_time=0, evict_time=0;
    while(fscanf(trace, " %c %lx,%d\n", &oper, &addr, &size) != EOF){
        if (oper != 'M' && oper != 'S' && oper != 'L') continue;
        if (v) printf("%c %lx,%d", oper, addr, size);
        switch (oper)
        {
            case 'M':
                visit(v, &hit_time, &miss_time, &evict_time, &cache, addr);
            case 'L':case 'S':
                visit(v, &hit_time, &miss_time, &evict_time, &cache, addr);
        }
        if (v) printf("\n");
    }
    fclose(trace);
    printSummary(hit_time, miss_time, evict_time);
    return 0;
}
